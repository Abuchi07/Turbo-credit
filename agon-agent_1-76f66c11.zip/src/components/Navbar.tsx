import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  const links = [
    { name: 'Home', path: '/' },
    { name: 'Loan Products', path: '/products' },
    { name: 'Calculator', path: '/calculator' },
    { name: 'About', path: '/about' },
    { name: 'Contact', path: '/contact' },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white backdrop-blur-lg border-b border-gray-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <Link to="/" className="flex items-center gap-3">
            <img src="/uploads/upload_1.png" alt="Turbo Credit" className="h-14 w-auto" style={{filter: 'drop-shadow(0 4px 8px rgba(26, 92, 255, 0.3))'}} />
            <span className="font-[Outfit] text-2xl font-bold text-turbo-blue">Turbo Credit</span>
          </Link>

          <div className="hidden md:flex items-center gap-8">
            {links.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`text-sm font-medium transition-colors ${
                  location.pathname === link.path
                    ? 'text-turbo-blue'
                    : 'text-gray-600 hover:text-turbo-blue'
                }`}
              >
                {link.name}
              </Link>
            ))}
            <Link
              to="/apply"
              className="bg-gradient-to-r from-turbo-blue to-turbo-accent text-white px-6 py-2.5 rounded-full font-semibold text-sm hover:shadow-lg hover:shadow-turbo-accent/30 transition-all"
            >
              Apply Now
            </Link>
          </div>

          <button
            className="md:hidden text-turbo-dark p-2"
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-white border-t border-gray-200"
          >
            <div className="px-4 py-4 space-y-3">
              {links.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  onClick={() => setIsOpen(false)}
                  className={`block py-2 text-sm font-medium ${
                    location.pathname === link.path
                      ? 'text-turbo-blue'
                      : 'text-gray-600'
                  }`}
                >
                  {link.name}
                </Link>
              ))}
              <Link
                to="/apply"
                onClick={() => setIsOpen(false)}
                className="block w-full text-center bg-gradient-to-r from-turbo-blue to-turbo-accent text-white px-6 py-3 rounded-full font-semibold text-sm"
              >
                Apply Now
              </Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
