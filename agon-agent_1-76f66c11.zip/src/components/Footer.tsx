import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin, Facebook, Twitter, Linkedin, Instagram } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-turbo-dark border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          <div>
            <Link to="/" className="flex items-center gap-3 mb-6">
              <img src="/uploads/upload_1.png" alt="Turbo Credit" className="h-12 w-auto" style={{filter: 'drop-shadow(0 4px 8px rgba(26, 92, 255, 0.4))'}} />
              <span className="font-[Outfit] text-xl font-bold text-turbo-blue">Turbo Credit</span>
            </Link>
            <p className="text-white/60 text-sm leading-relaxed mb-6">
              Fast, reliable credit to power your dreams. Get approved in minutes with competitive rates and flexible terms.
            </p>
            <div className="flex gap-4">
              {[Facebook, Twitter, Linkedin, Instagram].map((Icon, i) => (
                <a key={i} href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-white/60 hover:bg-turbo-accent hover:text-white transition-all">
                  <Icon size={18} />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-[Outfit] text-white font-semibold mb-6">Quick Links</h4>
            <ul className="space-y-3">
              {['Home', 'Loan Products', 'Calculator', 'About Us', 'Contact'].map((item) => (
                <li key={item}>
                  <a href="#" className="text-white/60 text-sm hover:text-turbo-accent transition-colors">{item}</a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-[Outfit] text-white font-semibold mb-6">Loan Types</h4>
            <ul className="space-y-3">
              {['Personal Loans', 'Business Loans', 'Auto Loans', 'Home Improvement', 'Debt Consolidation'].map((item) => (
                <li key={item}>
                  <a href="#" className="text-white/60 text-sm hover:text-turbo-accent transition-colors">{item}</a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-[Outfit] text-white font-semibold mb-6">Contact Us</h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <Phone size={18} className="text-turbo-accent mt-0.5" />
                <span className="text-white/60 text-sm">1-800-TURBO-HAT</span>
              </li>
              <li className="flex items-start gap-3">
                <Mail size={18} className="text-turbo-accent mt-0.5" />
                <span className="text-white/60 text-sm">hello@turbohatloans.com</span>
              </li>
              <li className="flex items-start gap-3">
                <MapPin size={18} className="text-turbo-accent mt-0.5" />
                <span className="text-white/60 text-sm">123 Finance Street<br />New York, NY 10001</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-white/40 text-sm">&copy; 2024 Turbo Credit. All rights reserved.</p>
          <div className="flex gap-6">
            <a href="#" className="text-white/40 text-sm hover:text-white/60">Privacy Policy</a>
            <a href="#" className="text-white/40 text-sm hover:text-white/60">Terms of Service</a>
            <a href="#" className="text-white/40 text-sm hover:text-white/60">Disclosures</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
