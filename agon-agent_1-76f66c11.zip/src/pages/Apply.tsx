import { useState } from 'react';
import { motion } from 'framer-motion';
import { User, Mail, Phone, DollarSign, Briefcase, Calendar, CheckCircle, ArrowRight, ArrowLeft, MapPin } from 'lucide-react';

export default function Apply() {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    full_name: '',
    email: '',
    phone: '',
    country: '',
    customCountry: '',
    loan_amount: 10000,
    loan_purpose: '',
    employment_status: '',
    annual_income: '',
    loan_term: 36,
  });

  const countries = [
    'United States',
    'Canada',
    'United Kingdom',
    'Australia',
    'Germany',
    'France',
    'Spain',
    'Italy',
    'Netherlands',
    'Belgium',
    'Switzerland',
    'Austria',
    'Sweden',
    'Norway',
    'Denmark',
    'Finland',
    'Ireland',
    'New Zealand',
    'Singapore',
    'Japan',
    'South Korea',
    'Mexico',
    'Costa Rica',
    'El Salvador',
    'Nicaragua',
    'Argentina',
    'Bolivia',
    'Brazil',
    'Chile',
    'Colombia',
    'Ecuador',
    'French Guiana',
    'Guyana',
    'Paraguay',
    'Peru',
    'Suriname',
    'Uruguay',
    'Venezuela',
    'India',
    'South Africa',
    'United Arab Emirates',
    'Saudi Arabia',
    'Other',
  ];

  const handleSubmit = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/loan-applications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      if (res.ok) {
        setSubmitted(true);
      }
    } catch (err) {
      console.error('Submit error:', err);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (num: number) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(num);
  };

  const purposes = [
    'Debt Consolidation',
    'Home Improvement',
    'Major Purchase',
    'Medical Expenses',
    'Business',
    'Vacation',
    'Wedding',
    'Other',
  ];

  const employmentOptions = [
    'Employed Full-Time',
    'Employed Part-Time',
    'Self-Employed',
    'Retired',
    'Student',
    'Other',
  ];

  if (submitted) {
    return (
      <div className="pt-20 min-h-screen flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-lg mx-auto px-4 text-center"
        >
          <div className="w-24 h-24 rounded-full bg-green-500/20 flex items-center justify-center mx-auto mb-6">
            <CheckCircle size={48} className="text-green-400" />
          </div>
          <h1 className="font-[Outfit] text-4xl font-bold text-white mb-4">Application Submitted!</h1>
          <p className="text-white/70 text-lg mb-8">
            Thank you for applying with Turbo Credit. We've received your application and will review it shortly. You'll receive an email with your decision within 24 hours.
          </p>
          <div className="bg-gradient-to-br from-white/10 to-white/5 rounded-2xl p-6 border border-white/10 mb-8">
            <div className="text-white/60 text-sm mb-2">Application Reference</div>
            <div className="font-mono text-2xl text-turbo-accent">TH-{Date.now().toString().slice(-8)}</div>
          </div>
          <a
            href="/"
            className="inline-flex items-center gap-2 bg-gradient-to-r from-turbo-blue to-turbo-accent text-white px-8 py-4 rounded-full font-semibold hover:shadow-lg hover:shadow-turbo-accent/30 transition-all"
          >
            Return Home
          </a>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="pt-20 min-h-screen">
      {/* Hero */}
      <section className="py-12 bg-gradient-to-b from-turbo-dark to-turbo-dark/95">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <h1 className="font-[Outfit] text-4xl md:text-5xl font-bold text-white mb-4">
              Apply for a <span className="text-turbo-accent">Loan</span>
            </h1>
            <p className="text-white/70 text-lg">
              Complete the form below to get started. It only takes a few minutes.
            </p>
          </motion.div>

          {/* Progress */}
          <div className="mt-12 flex items-center justify-center gap-4">
            {[1, 2, 3].map((s) => (
              <div key={s} className="flex items-center gap-4">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold transition-all ${
                    step >= s
                      ? 'bg-gradient-to-r from-turbo-blue to-turbo-accent text-white'
                      : 'bg-white/10 text-white/50'
                  }`}
                >
                  {s}
                </div>
                {s < 3 && (
                  <div className={`w-16 h-1 rounded-full transition-all ${step > s ? 'bg-turbo-accent' : 'bg-white/10'}`} />
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Form */}
      <section className="py-12 bg-turbo-dark/95">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            key={step}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-sm rounded-3xl p-8 border border-white/10"
          >
            {step === 1 && (
              <>
                <h2 className="font-[Outfit] text-2xl font-bold text-white mb-6">Personal Information</h2>
                <div className="space-y-6">
                  <div>
                    <label className="flex items-center gap-2 text-white/70 text-sm mb-2">
                      <User size={16} className="text-turbo-accent" />
                      Full Name
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.full_name}
                      onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-turbo-accent transition-colors"
                      placeholder="John Doe"
                    />
                  </div>
                  <div>
                    <label className="flex items-center gap-2 text-white/70 text-sm mb-2">
                      <Mail size={16} className="text-turbo-accent" />
                      Email Address
                    </label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-turbo-accent transition-colors"
                      placeholder="john@example.com"
                    />
                  </div>
                  <div>
                    <label className="flex items-center gap-2 text-white/70 text-sm mb-2">
                      <Phone size={16} className="text-turbo-accent" />
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-turbo-accent transition-colors"
                      placeholder="(555) 123-4567"
                    />
                  </div>
                  <div>
                    <label className="flex items-center gap-2 text-white/70 text-sm mb-2">
                      <MapPin size={16} className="text-turbo-accent" />
                      Country / Region
                    </label>
                    <select
                      value={formData.country}
                      onChange={(e) => setFormData({ ...formData, country: e.target.value, customCountry: '' })}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-turbo-accent transition-colors"
                    >
                      <option value="" className="bg-turbo-dark">Select your country</option>
                      {countries.map((country) => (
                        <option key={country} value={country} className="bg-turbo-dark">{country}</option>
                      ))}
                    </select>
                  </div>
                  {formData.country === 'Other' && (
                    <div>
                      <label className="flex items-center gap-2 text-white/70 text-sm mb-2">
                        <MapPin size={16} className="text-turbo-accent" />
                        Enter Your Country / Region
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.customCountry}
                        onChange={(e) => setFormData({ ...formData, customCountry: e.target.value })}
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-turbo-accent transition-colors"
                        placeholder="Enter your country or region"
                      />
                    </div>
                  )}
                </div>
              </>
            )}

            {step === 2 && (
              <>
                <h2 className="font-[Outfit] text-2xl font-bold text-white mb-6">Loan Details</h2>
                <div className="space-y-6">
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <label className="flex items-center gap-2 text-white/70">
                        <DollarSign size={16} className="text-turbo-accent" />
                        Loan Amount
                      </label>
                      <span className="text-white font-semibold">{formatCurrency(formData.loan_amount)}</span>
                    </div>
                    <input
                      type="range"
                      min="1000"
                      max="100000"
                      step="1000"
                      value={formData.loan_amount}
                      onChange={(e) => setFormData({ ...formData, loan_amount: Number(e.target.value) })}
                      className="w-full h-2 bg-white/10 rounded-full appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-5 [&::-webkit-slider-thumb]:h-5 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-turbo-accent [&::-webkit-slider-thumb]:cursor-pointer"
                    />
                    <div className="flex justify-between text-sm text-white/40 mt-2">
                      <span>$1,000</span>
                      <span>$100,000</span>
                    </div>
                  </div>

                  <div>
                    <label className="block text-white/70 text-sm mb-2">Loan Purpose</label>
                    <select
                      required
                      value={formData.loan_purpose}
                      onChange={(e) => setFormData({ ...formData, loan_purpose: e.target.value })}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-turbo-accent transition-colors"
                    >
                      <option value="" className="bg-turbo-dark">Select purpose</option>
                      {purposes.map((p) => (
                        <option key={p} value={p} className="bg-turbo-dark">{p}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <label className="flex items-center gap-2 text-white/70">
                        <Calendar size={16} className="text-turbo-accent" />
                        Loan Term
                      </label>
                      <span className="text-white font-semibold">{formData.loan_term} months</span>
                    </div>
                    <input
                      type="range"
                      min="12"
                      max="84"
                      step="12"
                      value={formData.loan_term}
                      onChange={(e) => setFormData({ ...formData, loan_term: Number(e.target.value) })}
                      className="w-full h-2 bg-white/10 rounded-full appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-5 [&::-webkit-slider-thumb]:h-5 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-turbo-accent [&::-webkit-slider-thumb]:cursor-pointer"
                    />
                    <div className="flex justify-between text-sm text-white/40 mt-2">
                      <span>12 months</span>
                      <span>84 months</span>
                    </div>
                  </div>
                </div>
              </>
            )}

            {step === 3 && (
              <>
                <h2 className="font-[Outfit] text-2xl font-bold text-white mb-6">Employment & Income</h2>
                <div className="space-y-6">
                  <div>
                    <label className="flex items-center gap-2 text-white/70 text-sm mb-2">
                      <Briefcase size={16} className="text-turbo-accent" />
                      Employment Status
                    </label>
                    <select
                      required
                      value={formData.employment_status}
                      onChange={(e) => setFormData({ ...formData, employment_status: e.target.value })}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-turbo-accent transition-colors"
                    >
                      <option value="" className="bg-turbo-dark">Select status</option>
                      {employmentOptions.map((e) => (
                        <option key={e} value={e} className="bg-turbo-dark">{e}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="flex items-center gap-2 text-white/70 text-sm mb-2">
                      <DollarSign size={16} className="text-turbo-accent" />
                      Annual Income
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.annual_income}
                      onChange={(e) => setFormData({ ...formData, annual_income: e.target.value })}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-turbo-accent transition-colors"
                      placeholder="$75,000"
                    />
                  </div>

                  {/* Summary */}
                  <div className="bg-white/5 rounded-xl p-6 mt-8">
                    <h3 className="font-semibold text-white mb-4">Application Summary</h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-white/60">Name</span>
                        <span className="text-white">{formData.full_name}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-white/60">Country</span>
                        <span className="text-white">{formData.country === 'Other' ? formData.customCountry : formData.country}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-white/60">Loan Amount</span>
                        <span className="text-white">{formatCurrency(formData.loan_amount)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-white/60">Purpose</span>
                        <span className="text-white">{formData.loan_purpose}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-white/60">Term</span>
                        <span className="text-white">{formData.loan_term} months</span>
                      </div>
                    </div>
                  </div>
                </div>
              </>
            )}

            {/* Navigation */}
            <div className="flex gap-4 mt-8">
              {step > 1 && (
                <button
                  onClick={() => setStep(step - 1)}
                  className="flex items-center justify-center gap-2 flex-1 bg-white/10 text-white py-4 rounded-xl font-semibold hover:bg-white/20 transition-all"
                >
                  <ArrowLeft size={18} />
                  Back
                </button>
              )}
              {step < 3 ? (
                <button
                  onClick={() => setStep(step + 1)}
                  disabled={step === 1 && (!formData.full_name || !formData.email || !formData.phone || !formData.country || (formData.country === 'Other' && !formData.customCountry))}
                  className="flex items-center justify-center gap-2 flex-1 bg-gradient-to-r from-turbo-blue to-turbo-accent text-white py-4 rounded-xl font-semibold hover:shadow-lg hover:shadow-turbo-accent/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Continue
                  <ArrowRight size={18} />
                </button>
              ) : (
                <button
                  onClick={handleSubmit}
                  disabled={loading || !formData.employment_status || !formData.annual_income}
                  className="flex items-center justify-center gap-2 flex-1 bg-gradient-to-r from-turbo-blue to-turbo-accent text-white py-4 rounded-xl font-semibold hover:shadow-lg hover:shadow-turbo-accent/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {loading ? 'Submitting...' : 'Submit Application'}
                  <CheckCircle size={18} />
                </button>
              )}
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
