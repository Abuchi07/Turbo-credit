import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Calculator as CalcIcon, DollarSign, Percent, Calendar, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Calculator() {
  const [loanAmount, setLoanAmount] = useState(25000);
  const [interestRate, setInterestRate] = useState(7.99);
  const [loanTerm, setLoanTerm] = useState(36);
  const [monthlyPayment, setMonthlyPayment] = useState(0);
  const [totalPayment, setTotalPayment] = useState(0);
  const [totalInterest, setTotalInterest] = useState(0);

  useEffect(() => {
    const principal = loanAmount;
    const monthlyRate = interestRate / 100 / 12;
    const numberOfPayments = loanTerm;

    if (monthlyRate === 0) {
      const payment = principal / numberOfPayments;
      setMonthlyPayment(payment);
      setTotalPayment(principal);
      setTotalInterest(0);
    } else {
      const payment = (principal * monthlyRate * Math.pow(1 + monthlyRate, numberOfPayments)) / 
                      (Math.pow(1 + monthlyRate, numberOfPayments) - 1);
      const total = payment * numberOfPayments;
      const interest = total - principal;

      setMonthlyPayment(payment);
      setTotalPayment(total);
      setTotalInterest(interest);
    }
  }, [loanAmount, interestRate, loanTerm]);

  const formatCurrency = (num: number) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 2 }).format(num);
  };

  return (
    <div className="pt-20 min-h-screen">
      {/* Hero */}
      <section className="py-20 bg-gradient-to-b from-turbo-dark to-turbo-dark/95">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-gradient-to-br from-turbo-blue to-turbo-accent mb-6">
              <CalcIcon size={40} className="text-white" />
            </div>
            <h1 className="font-[Outfit] text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6">
              Loan <span className="text-turbo-accent">Calculator</span>
            </h1>
            <p className="text-white/70 text-xl max-w-2xl mx-auto">
              Estimate your monthly payments and see how much you could save with Turbohat Loans.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Calculator */}
      <section className="py-20 bg-turbo-dark/95">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-8">
            {/* Inputs */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-sm rounded-3xl p-8 border border-white/10"
            >
              <h2 className="font-[Outfit] text-2xl font-bold text-white mb-8">Adjust Your Loan</h2>

              {/* Loan Amount */}
              <div className="mb-8">
                <div className="flex items-center justify-between mb-3">
                  <label className="flex items-center gap-2 text-white/70">
                    <DollarSign size={18} className="text-turbo-accent" />
                    Loan Amount
                  </label>
                  <span className="text-white font-semibold">{formatCurrency(loanAmount)}</span>
                </div>
                <input
                  type="range"
                  min="1000"
                  max="100000"
                  step="1000"
                  value={loanAmount}
                  onChange={(e) => setLoanAmount(Number(e.target.value))}
                  className="w-full h-2 bg-white/10 rounded-full appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-5 [&::-webkit-slider-thumb]:h-5 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-turbo-accent [&::-webkit-slider-thumb]:cursor-pointer [&::-webkit-slider-thumb]:shadow-lg [&::-webkit-slider-thumb]:shadow-turbo-accent/30"
                />
                <div className="flex justify-between text-sm text-white/40 mt-2">
                  <span>$1,000</span>
                  <span>$100,000</span>
                </div>
              </div>

              {/* Interest Rate */}
              <div className="mb-8">
                <div className="flex items-center justify-between mb-3">
                  <label className="flex items-center gap-2 text-white/70">
                    <Percent size={18} className="text-turbo-accent" />
                    Interest Rate (APR)
                  </label>
                  <span className="text-white font-semibold">{interestRate.toFixed(2)}%</span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="25"
                  step="0.01"
                  value={interestRate}
                  onChange={(e) => setInterestRate(Number(e.target.value))}
                  className="w-full h-2 bg-white/10 rounded-full appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-5 [&::-webkit-slider-thumb]:h-5 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-turbo-accent [&::-webkit-slider-thumb]:cursor-pointer [&::-webkit-slider-thumb]:shadow-lg [&::-webkit-slider-thumb]:shadow-turbo-accent/30"
                />
                <div className="flex justify-between text-sm text-white/40 mt-2">
                  <span>5%</span>
                  <span>25%</span>
                </div>
              </div>

              {/* Loan Term */}
              <div className="mb-8">
                <div className="flex items-center justify-between mb-3">
                  <label className="flex items-center gap-2 text-white/70">
                    <Calendar size={18} className="text-turbo-accent" />
                    Loan Term
                  </label>
                  <span className="text-white font-semibold">{loanTerm} months</span>
                </div>
                <input
                  type="range"
                  min="12"
                  max="84"
                  step="12"
                  value={loanTerm}
                  onChange={(e) => setLoanTerm(Number(e.target.value))}
                  className="w-full h-2 bg-white/10 rounded-full appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-5 [&::-webkit-slider-thumb]:h-5 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-turbo-accent [&::-webkit-slider-thumb]:cursor-pointer [&::-webkit-slider-thumb]:shadow-lg [&::-webkit-slider-thumb]:shadow-turbo-accent/30"
                />
                <div className="flex justify-between text-sm text-white/40 mt-2">
                  <span>12 mo</span>
                  <span>84 mo</span>
                </div>
              </div>
            </motion.div>

            {/* Results */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-6"
            >
              {/* Monthly Payment */}
              <div className="bg-gradient-to-br from-turbo-blue to-turbo-accent rounded-3xl p-8 text-center">
                <div className="text-white/80 mb-2">Estimated Monthly Payment</div>
                <div className="text-5xl font-[Outfit] font-bold text-white">
                  {formatCurrency(monthlyPayment)}
                </div>
              </div>

              {/* Summary */}
              <div className="bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-sm rounded-3xl p-8 border border-white/10">
                <h3 className="font-[Outfit] text-xl font-bold text-white mb-6">Loan Summary</h3>
                <div className="space-y-4">
                  <div className="flex justify-between items-center py-3 border-b border-white/10">
                    <span className="text-white/60">Principal Amount</span>
                    <span className="text-white font-semibold">{formatCurrency(loanAmount)}</span>
                  </div>
                  <div className="flex justify-between items-center py-3 border-b border-white/10">
                    <span className="text-white/60">Total Interest</span>
                    <span className="text-turbo-accent font-semibold">{formatCurrency(totalInterest)}</span>
                  </div>
                  <div className="flex justify-between items-center py-3">
                    <span className="text-white/60">Total Payment</span>
                    <span className="text-white font-bold text-xl">{formatCurrency(totalPayment)}</span>
                  </div>
                </div>
              </div>

              {/* CTA */}
              <Link
                to="/apply"
                className="flex items-center justify-center gap-2 w-full bg-gradient-to-r from-turbo-blue to-turbo-accent text-white py-4 rounded-xl font-semibold text-lg hover:shadow-lg hover:shadow-turbo-accent/30 transition-all group"
              >
                Apply for This Loan
                <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
              </Link>
            </motion.div>
          </div>

          {/* Disclaimer */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="text-white/40 text-sm text-center mt-12"
          >
            * This calculator provides estimates for informational purposes only. Actual loan terms, including APR and monthly payments, may vary based on credit history, income, and other factors. Contact us for a personalized quote.
          </motion.p>
        </div>
      </section>
    </div>
  );
}
