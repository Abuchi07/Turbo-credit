import { motion } from 'framer-motion';
import { Heart, Target, Lightbulb } from 'lucide-react';

export default function About() {
  const stats = [
    { value: '$500M+', label: 'Loans Funded' },
    { value: '50,000+', label: 'Happy Customers' },
    { value: '4.9/5', label: 'Customer Rating' },
    { value: '10+', label: 'Years Experience' },
  ];

  const values = [
    { icon: Heart, title: 'Customer First', desc: 'We put our customers at the heart of everything we do, ensuring personalized service and support.' },
    { icon: Target, title: 'Transparency', desc: 'No hidden fees, no surprises. We believe in clear, honest communication about all loan terms.' },
    { icon: Lightbulb, title: 'Innovation', desc: 'We leverage cutting-edge technology to make the lending process faster and more accessible.' },
  ];

  const team = [
    { name: 'Sarah Johnson', role: 'CEO & Founder', image: '👩‍💼' },
    { name: 'Michael Chen', role: 'Chief Financial Officer', image: '👨‍💼' },
    { name: 'Emily Rodriguez', role: 'Head of Operations', image: '👩‍💻' },
    { name: 'David Kim', role: 'Chief Technology Officer', image: '👨‍💻' },
  ];

  return (
    <div className="pt-20 min-h-screen">
      {/* Hero */}
      <section className="py-20 bg-gradient-to-b from-turbo-dark to-turbo-dark/95">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
            >
              <h1 className="font-[Outfit] text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6">
                About <span className="text-turbo-accent">Turbo Credit</span>
              </h1>
              <p className="text-white/70 text-xl leading-relaxed mb-8">
                We're on a mission to make lending accessible, transparent, and fast. Founded in 2014, Turbo Credit has grown to become one of the most trusted names in personal lending.
              </p>
              <p className="text-white/60 leading-relaxed">
                Our innovative approach combines cutting-edge technology with personalized service to deliver an exceptional borrowing experience. We believe everyone deserves access to fair, affordable credit.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              className="relative"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-turbo-accent to-turbo-blue rounded-3xl blur-2xl opacity-20" />
              <div className="relative bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-xl rounded-3xl p-8 border border-white/20">
                <img src="/uploads/upload_1.png" alt="Turbo Credit" className="w-full max-w-sm mx-auto" style={{filter: 'drop-shadow(0 10px 25px rgba(26, 92, 255, 0.4))'}} />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-16 bg-turbo-dark/95">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, i) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="text-center"
              >
                <div className="text-4xl md:text-5xl font-[Outfit] font-bold bg-gradient-to-r from-turbo-accent to-turbo-blue bg-clip-text text-transparent mb-2">
                  {stat.value}
                </div>
                <div className="text-white/60">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Our Values */}
      <section className="py-20 bg-turbo-dark">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="font-[Outfit] text-3xl md:text-4xl font-bold text-white mb-4">Our Values</h2>
            <p className="text-white/60 text-lg max-w-2xl mx-auto">
              These core principles guide everything we do at Turbo Credit
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {values.map((value, i) => (
              <motion.div
                key={value.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/10 text-center"
              >
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-turbo-blue to-turbo-accent mb-6">
                  <value.icon size={32} className="text-white" />
                </div>
                <h3 className="font-[Outfit] text-2xl font-semibold text-white mb-4">{value.title}</h3>
                <p className="text-white/60 leading-relaxed">{value.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-20 bg-gradient-to-b from-turbo-dark to-turbo-dark/95">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="font-[Outfit] text-3xl md:text-4xl font-bold text-white mb-4">Our Leadership Team</h2>
            <p className="text-white/60 text-lg max-w-2xl mx-auto">
              Meet the people driving our mission forward
            </p>
          </motion.div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {team.map((member, i) => (
              <motion.div
                key={member.name}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10 text-center group hover:border-turbo-accent/50 transition-all"
              >
                <div className="text-6xl mb-4">{member.image}</div>
                <h3 className="font-[Outfit] text-xl font-semibold text-white mb-1">{member.name}</h3>
                <p className="text-turbo-accent text-sm">{member.role}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Mission */}
      <section className="py-20 bg-turbo-dark/95">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="relative overflow-hidden rounded-3xl"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-turbo-blue to-turbo-accent" />
            <div className="relative text-center py-16 px-8">
              <h2 className="font-[Outfit] text-3xl md:text-4xl font-bold text-white mb-6">Our Mission</h2>
              <p className="text-white/90 text-xl leading-relaxed max-w-2xl mx-auto">
                "To empower individuals and families with accessible, fair, and transparent lending solutions that help them achieve their financial goals and build a brighter future."
              </p>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
