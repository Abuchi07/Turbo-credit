import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight, Shield, Zap, Clock, TrendingUp, Star, ChevronDown, ChevronUp } from 'lucide-react';

interface LoanProduct {
  id: number;
  name: string;
  description: string;
  min_amount: number;
  max_amount: number;
  min_rate: number;
  max_rate: number;
  min_term: number;
  max_term: number;
  icon: string;
}

interface Testimonial {
  id: number;
  name: string;
  role: string;
  content: string;
  rating: number;
  avatar_url: string;
}

interface FAQ {
  id: number;
  question: string;
  answer: string;
}

export default function Home() {
  const [products, setProducts] = useState<LoanProduct[]>([]);
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const [faqs, setFaqs] = useState<FAQ[]>([]);
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [prodRes, testRes, faqRes] = await Promise.all([
          fetch('/api/loan-products'),
          fetch('/api/testimonials'),
          fetch('/api/faqs')
        ]);
        const [prodData, testData, faqData] = await Promise.all([
          prodRes.json(),
          testRes.json(),
          faqRes.json()
        ]);
        setProducts(prodData);
        setTestimonials(testData);
        setFaqs(faqData);
      } catch (err) {
        console.error('Fetch error:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const features = [
    { icon: Zap, title: 'Lightning Fast', desc: 'Get approved in as little as 5 minutes' },
    { icon: Shield, title: 'Secure & Safe', desc: 'Bank-level encryption protects your data' },
    { icon: Clock, title: 'Quick Funding', desc: 'Funds deposited within 24 hours' },
    { icon: TrendingUp, title: 'Low Rates', desc: 'Competitive rates starting at 5.99% APR' },
  ];

  const formatCurrency = (num: number) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(num);
  };

  return (
    <div className="pt-20 bg-turbo-dark">
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-turbo-dark via-turbo-dark to-turbo-blue/30" />
        <div className="absolute inset-0">
          <div className="absolute top-20 left-10 w-72 h-72 bg-turbo-accent/20 rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-turbo-blue/20 rounded-full blur-3xl" />
        </div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <div className="inline-flex items-center gap-2 bg-gradient-to-r from-turbo-accent/20 to-turbo-blue/20 backdrop-blur-sm rounded-full px-5 py-2.5 mb-6 border border-turbo-accent/30">
                <span className="text-2xl">⚡</span>
                <span className="font-[Outfit] font-bold text-turbo-accent text-lg tracking-wide">TURBO SPEED LENDING</span>
              </div>
              <h1 className="font-[Outfit] text-5xl md:text-6xl lg:text-7xl font-bold text-white leading-tight mb-6">
                Turbocharge Your
                <span className="bg-gradient-to-r from-turbo-accent to-turbo-blue bg-clip-text text-transparent"> Financial Future</span>
              </h1>
              <p className="text-xl text-white/70 mb-8 leading-relaxed">
                Get the funds you need with lightning-fast approval. Personal loans from $1,000 to $100,000 with flexible terms and competitive rates.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  to="/apply"
                  className="inline-flex items-center justify-center gap-2 bg-gradient-to-r from-turbo-blue to-turbo-accent text-white px-8 py-4 rounded-full font-semibold text-lg hover:shadow-xl hover:shadow-turbo-accent/30 transition-all group"
                >
                  Apply Now
                  <ArrowRight className="group-hover:translate-x-1 transition-transform" />
                </Link>
                <Link
                  to="/calculator"
                  className="inline-flex items-center justify-center gap-2 bg-white/10 backdrop-blur-sm text-white px-8 py-4 rounded-full font-semibold text-lg hover:bg-white/20 transition-all"
                >
                  Calculate Payments
                </Link>
              </div>
              <div className="mt-12 flex items-center gap-8">
                <div>
                  <div className="text-3xl font-[Outfit] font-bold text-white">$500M+</div>
                  <div className="text-white/50 text-sm">Loans Funded</div>
                </div>
                <div className="w-px h-12 bg-white/20" />
                <div>
                  <div className="text-3xl font-[Outfit] font-bold text-white">50K+</div>
                  <div className="text-white/50 text-sm">Happy Customers</div>
                </div>
                <div className="w-px h-12 bg-white/20" />
                <div>
                  <div className="text-3xl font-[Outfit] font-bold text-white">4.9★</div>
                  <div className="text-white/50 text-sm">Customer Rating</div>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="hidden lg:block"
            >
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-turbo-blue to-turbo-accent rounded-3xl blur-2xl opacity-20" />
                <div className="relative bg-gradient-to-br from-turbo-blue/5 to-turbo-accent/5 backdrop-blur-xl rounded-3xl p-8 border border-turbo-blue/20 shadow-2xl">
                  <img src="/uploads/upload_1.png" alt="Turbo Credit" className="w-full max-w-sm mx-auto" style={{filter: 'drop-shadow(0 10px 25px rgba(26, 92, 255, 0.4))'}} />
                  <div className="mt-6 text-center">
                    <div className="text-gray-500 text-sm">Quick Approval</div>
                    <div className="text-4xl font-[Outfit] font-bold text-turbo-dark mt-1">5 Minutes</div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, i) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-white rounded-2xl p-6 border border-gray-200 hover:border-turbo-blue/50 hover:shadow-lg transition-all group"
              >
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-turbo-blue to-turbo-accent flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <feature.icon className="text-white" size={24} />
                </div>
                <h3 className="font-[Outfit] text-xl font-semibold text-turbo-dark mb-2">{feature.title}</h3>
                <p className="text-gray-600 text-sm">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Loan Products Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="font-[Outfit] text-4xl md:text-5xl font-bold text-turbo-dark mb-4">Our Loan Products</h2>
            <p className="text-gray-600 text-lg max-w-2xl mx-auto">Choose the perfect loan for your needs with flexible terms and competitive rates</p>
          </motion.div>

          {loading ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3].map((i) => (
                <div key={i} className="bg-gray-100 rounded-2xl p-6 animate-pulse">
                  <div className="w-16 h-16 bg-gray-200 rounded-xl mb-4" />
                  <div className="h-6 bg-gray-200 rounded w-2/3 mb-2" />
                  <div className="h-4 bg-gray-200 rounded w-full mb-4" />
                  <div className="h-4 bg-gray-200 rounded w-1/2" />
                </div>
              ))}
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {products.map((product, i) => (
                <motion.div
                  key={product.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="bg-white rounded-2xl p-6 border border-gray-200 hover:border-turbo-blue/50 hover:shadow-lg transition-all group"
                >
                  <div className="text-4xl mb-4">{product.icon}</div>
                  <h3 className="font-[Outfit] text-2xl font-semibold text-turbo-dark mb-2">{product.name}</h3>
                  <p className="text-gray-600 text-sm mb-4">{product.description}</p>
                  <div className="space-y-2 mb-6">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500">Amount</span>
                      <span className="text-turbo-dark">{formatCurrency(product.min_amount)} - {formatCurrency(product.max_amount)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500">APR</span>
                      <span className="text-turbo-blue font-semibold">{product.min_rate}% - {product.max_rate}%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500">Term</span>
                      <span className="text-turbo-dark">{product.min_term} - {product.max_term} months</span>
                    </div>
                  </div>
                  <Link
                    to="/apply"
                    className="block w-full text-center bg-gradient-to-r from-turbo-blue to-turbo-accent hover:shadow-lg text-white py-3 rounded-xl font-semibold transition-all"
                  >
                    Apply Now
                  </Link>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Why Choose Turbo Credit */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="font-[Outfit] text-4xl md:text-5xl font-bold text-turbo-dark mb-4">Why Choose <span className="text-turbo-blue">Turbo Credit?</span></h2>
            <p className="text-gray-600 text-lg max-w-2xl mx-auto">We're not just another lender. Here's what makes us different.</p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { icon: '🚀', title: 'Lightning-Fast Approval', desc: 'Get approved in as little as 5 minutes. Our advanced technology evaluates your application instantly, so you\'re not left waiting.' },
              { icon: '💰', title: 'Competitive Rates', desc: 'We offer some of the lowest rates in the industry, starting at just 5.99% APR. Save thousands over the life of your loan.' },
              { icon: '🔒', title: 'Bank-Level Security', desc: 'Your data is protected with 256-bit encryption. We never sell your information and maintain strict privacy standards.' },
              { icon: '📱', title: '100% Online Process', desc: 'Apply from anywhere, anytime. No branch visits, no paperwork. Everything is handled digitally for your convenience.' },
              { icon: '🎯', title: 'No Hidden Fees', desc: 'What you see is what you get. No origination fees, no prepayment penalties, and no surprise charges. Ever.' },
              { icon: '🤝', title: 'Dedicated Support', desc: 'Our friendly loan specialists are available 7 days a week to answer your questions and guide you through the process.' },
            ].map((item, i) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-white rounded-2xl p-8 border border-gray-200 hover:border-turbo-blue/50 hover:shadow-lg transition-all group"
              >
                <div className="text-5xl mb-5">{item.icon}</div>
                <h3 className="font-[Outfit] text-xl font-semibold text-turbo-dark mb-3">{item.title}</h3>
                <p className="text-gray-600 leading-relaxed">{item.desc}</p>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mt-16 text-center"
          >
            <div className="inline-flex flex-wrap justify-center gap-8 md:gap-16 bg-gradient-to-r from-turbo-blue to-turbo-accent rounded-2xl px-8 py-6 shadow-lg">
              <div className="text-center">
                <div className="text-3xl font-[Outfit] font-bold text-white">A+</div>
                <div className="text-white/70 text-sm">BBB Rating</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-[Outfit] font-bold text-white">4.9/5</div>
                <div className="text-white/70 text-sm">Trustpilot Score</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-[Outfit] font-bold text-white">24hrs</div>
                <div className="text-white/70 text-sm">Avg. Funding Time</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-[Outfit] font-bold text-white">0</div>
                <div className="text-white/70 text-sm">Hidden Fees</div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="font-[Outfit] text-4xl md:text-5xl font-bold text-turbo-dark mb-4">How It Works</h2>
            <p className="text-gray-600 text-lg">Get funded in three simple steps</p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              { step: '01', title: 'Apply Online', desc: 'Fill out our simple application form in just 5 minutes. No paperwork needed.' },
              { step: '02', title: 'Get Approved', desc: 'Receive an instant decision. Most applications are approved within minutes.' },
              { step: '03', title: 'Get Funded', desc: 'Accept your loan offer and receive funds directly in your bank account.' },
            ].map((item, i) => (
              <motion.div
                key={item.step}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.2 }}
                className="text-center relative"
              >
                <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br from-turbo-blue to-turbo-accent text-white font-[Outfit] text-2xl font-bold mb-6">
                  {item.step}
                </div>
                {i < 2 && (
                  <div className="hidden md:block absolute top-10 left-[60%] w-[80%] h-0.5 bg-gradient-to-r from-turbo-blue/50 to-transparent" />
                )}
                <h3 className="font-[Outfit] text-2xl font-semibold text-turbo-dark mb-3">{item.title}</h3>
                <p className="text-gray-600">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="font-[Outfit] text-4xl md:text-5xl font-bold text-turbo-dark mb-4">What Our Customers Say</h2>
            <p className="text-gray-600 text-lg">Join thousands of satisfied customers</p>
          </motion.div>

          {loading ? (
            <div className="grid md:grid-cols-3 gap-6">
              {[1, 2, 3].map((i) => (
                <div key={i} className="bg-white rounded-2xl p-6 animate-pulse">
                  <div className="h-24 bg-gray-200 rounded mb-4" />
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-gray-200 rounded-full" />
                    <div className="flex-1">
                      <div className="h-4 bg-gray-200 rounded w-2/3 mb-2" />
                      <div className="h-3 bg-gray-200 rounded w-1/2" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid md:grid-cols-3 gap-6">
              {testimonials.map((testimonial, i) => (
                <motion.div
                  key={testimonial.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="bg-white rounded-2xl p-6 border border-gray-200 hover:shadow-lg transition-all"
                >
                  <div className="flex gap-1 mb-4">
                    {[...Array(testimonial.rating)].map((_, j) => (
                      <Star key={j} size={18} className="text-yellow-500 fill-yellow-500" />
                    ))}
                  </div>
                  <p className="text-gray-700 mb-6 leading-relaxed">"{testimonial.content}"</p>
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-turbo-blue to-turbo-accent flex items-center justify-center text-white font-bold">
                      {testimonial.name.charAt(0)}
                    </div>
                    <div>
                      <div className="font-semibold text-turbo-dark">{testimonial.name}</div>
                      <div className="text-gray-500 text-sm">{testimonial.role}</div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-white">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="font-[Outfit] text-4xl md:text-5xl font-bold text-turbo-dark mb-4">Frequently Asked Questions</h2>
            <p className="text-gray-600 text-lg">Got questions? We've got answers</p>
          </motion.div>

          <div className="space-y-4">
            {faqs.map((faq, i) => (
              <motion.div
                key={faq.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-gray-50 rounded-xl border border-gray-200 overflow-hidden"
              >
                <button
                  onClick={() => setOpenFaq(openFaq === faq.id ? null : faq.id)}
                  className="w-full flex items-center justify-between p-5 text-left"
                >
                  <span className="font-semibold text-turbo-dark">{faq.question}</span>
                  {openFaq === faq.id ? (
                    <ChevronUp className="text-turbo-blue" size={20} />
                  ) : (
                    <ChevronDown className="text-gray-400" size={20} />
                  )}
                </button>
                {openFaq === faq.id && (
                  <div className="px-5 pb-5 text-gray-600 leading-relaxed">
                    {faq.answer}
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="relative overflow-hidden rounded-3xl"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-turbo-blue to-turbo-accent" />
            <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg width=%2260%22 height=%2260%22 viewBox=%220 0 60 60%22 xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cg fill=%22none%22 fill-rule=%22evenodd%22%3E%3Cg fill=%22%23ffffff%22 fill-opacity=%220.1%22%3E%3Cpath d=%22M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z%22/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')]" />
            <div className="relative text-center py-16 px-8">
              <h2 className="font-[Outfit] text-3xl md:text-4xl font-bold text-white mb-4">Ready to Get Started?</h2>
              <p className="text-white/90 text-lg mb-8 max-w-xl mx-auto">
                Apply now and get your funds as soon as tomorrow. No hidden fees, no surprises.
              </p>
              <Link
                to="/apply"
                className="inline-flex items-center gap-2 bg-white text-turbo-blue px-8 py-4 rounded-full font-bold text-lg hover:bg-white/90 transition-all group"
              >
                Apply for a Loan
                <ArrowRight className="group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
