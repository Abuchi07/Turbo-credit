import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Check, ArrowRight } from 'lucide-react';

interface LoanProduct {
  id: number;
  name: string;
  description: string;
  min_amount: number;
  max_amount: number;
  min_rate: number;
  max_rate: number;
  min_term: number;
  max_term: number;
  icon: string;
}

export default function Products() {
  const [products, setProducts] = useState<LoanProduct[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const res = await fetch('/api/loan-products');
        const data = await res.json();
        setProducts(data);
      } catch (err) {
        console.error('Fetch error:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchProducts();
  }, []);

  const formatCurrency = (num: number) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(num);
  };

  const benefits = [
    'No hidden fees or charges',
    'Flexible repayment options',
    'Quick online application',
    'Dedicated customer support',
    'Competitive interest rates',
    'No prepayment penalties',
  ];

  return (
    <div className="pt-20 min-h-screen">
      {/* Hero */}
      <section className="py-20 bg-gradient-to-b from-turbo-dark to-turbo-dark/95">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <h1 className="font-[Outfit] text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6">
              Our Loan <span className="text-turbo-accent">Products</span>
            </h1>
            <p className="text-white/70 text-xl max-w-2xl mx-auto">
              Find the perfect loan for your needs. We offer a variety of loan products with competitive rates and flexible terms.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Products Grid */}
      <section className="py-20 bg-turbo-dark/95">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {loading ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="bg-white/5 rounded-2xl p-8 animate-pulse">
                  <div className="w-16 h-16 bg-white/10 rounded-xl mb-6" />
                  <div className="h-8 bg-white/10 rounded w-2/3 mb-4" />
                  <div className="h-4 bg-white/10 rounded w-full mb-2" />
                  <div className="h-4 bg-white/10 rounded w-3/4 mb-6" />
                  <div className="space-y-2">
                    <div className="h-4 bg-white/10 rounded w-full" />
                    <div className="h-4 bg-white/10 rounded w-full" />
                    <div className="h-4 bg-white/10 rounded w-full" />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {products.map((product, i) => (
                <motion.div
                  key={product.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/10 hover:border-turbo-accent/50 transition-all group"
                >
                  <div className="text-5xl mb-6">{product.icon}</div>
                  <h3 className="font-[Outfit] text-2xl font-bold text-white mb-3">{product.name}</h3>
                  <p className="text-white/60 mb-6 leading-relaxed">{product.description}</p>
                  
                  <div className="space-y-4 mb-8">
                    <div className="flex justify-between items-center py-3 border-b border-white/10">
                      <span className="text-white/50">Loan Amount</span>
                      <span className="text-white font-semibold">{formatCurrency(product.min_amount)} - {formatCurrency(product.max_amount)}</span>
                    </div>
                    <div className="flex justify-between items-center py-3 border-b border-white/10">
                      <span className="text-white/50">APR Range</span>
                      <span className="text-turbo-accent font-semibold">{product.min_rate}% - {product.max_rate}%</span>
                    </div>
                    <div className="flex justify-between items-center py-3 border-b border-white/10">
                      <span className="text-white/50">Loan Term</span>
                      <span className="text-white font-semibold">{product.min_term} - {product.max_term} months</span>
                    </div>
                  </div>

                  <Link
                    to="/apply"
                    className="flex items-center justify-center gap-2 w-full bg-gradient-to-r from-turbo-blue to-turbo-accent text-white py-4 rounded-xl font-semibold hover:shadow-lg hover:shadow-turbo-accent/30 transition-all group"
                  >
                    Apply Now
                    <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
                  </Link>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Benefits */}
      <section className="py-20 bg-turbo-dark">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="font-[Outfit] text-3xl md:text-4xl font-bold text-white mb-6">
                Why Choose <span className="text-turbo-accent">Turbo Credit?</span>
              </h2>
              <p className="text-white/70 text-lg mb-8">
                We're committed to making the lending process as simple and transparent as possible. Here's what sets us apart.
              </p>
              <div className="grid sm:grid-cols-2 gap-4">
                {benefits.map((benefit, i) => (
                  <motion.div
                    key={benefit}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.1 }}
                    className="flex items-center gap-3"
                  >
                    <div className="w-6 h-6 rounded-full bg-turbo-accent/20 flex items-center justify-center flex-shrink-0">
                      <Check size={14} className="text-turbo-accent" />
                    </div>
                    <span className="text-white/80">{benefit}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-turbo-accent to-turbo-blue rounded-3xl blur-2xl opacity-20" />
              <div className="relative bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-xl rounded-3xl p-8 border border-white/20">
                <img src="/uploads/upload_1.png" alt="Turbo Credit" className="w-full max-w-xs mx-auto mb-6" style={{filter: 'drop-shadow(0 10px 25px rgba(26, 92, 255, 0.4))'}} />
                <div className="text-center">
                  <div className="text-white/60 mb-2">Trusted by over</div>
                  <div className="text-4xl font-[Outfit] font-bold text-white">50,000+</div>
                  <div className="text-turbo-accent">Happy Customers</div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  );
}
